# Adding UTF-8 BOM to Any Payload

You can use this script for any payload. Ideally, use it after generating the file and just before sending the message to the receiver.
