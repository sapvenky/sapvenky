# CSV to XML Example (Manual)

This script example is contributed by Suraj Shelke.

It illustrates how you can work with splitting, arrays, and loops in Groovy.

Since there might be many edge cases with CSV, you should also consider using a library like Apache Commons CSV.

