# Log All the HTTP Headers as JSON

This is a simple script that will log all headers as pretty JSON. It can be useful for debugging incoming HTTP requests.
