# MPL Payload Log

Basic MPL logging to see the payload in the monitoring.

You don't have to import any library to use `messageLogFactory`. It is already "injected" to your script.

